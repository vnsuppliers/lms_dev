@include('layouts.admin.header')

<div class="container-fluid py-3">
    <!-- Page Header & Breadcrumb -->
    <div class="row mb-3 align-items-center">
        <div class="col-md-6">
            <h4 class="mb-1 text-dark fw-bold"><i class="fa-solid fa-chart-pie text-teal me-2" style="color: #008080;"></i>Dynamic LMS Reports</h4>
            <p class="text-muted mb-0 font-smallsize">Build, customize, filter, visualize and export reports across all LMS data sources.</p>
        </div>
        <div class="col-md-6 text-md-end mt-2 mt-md-0">
            <a href="{{ route('admin.reports.create') }}" class="btn btn-primary" style="background-color: #008080; border-color: #008080;">
                <i class="fa-solid fa-plus me-1"></i> Create New Report
            </a>
        </div>
    </div>

    <!-- Alert Notifications -->
    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fa-solid fa-circle-check me-2"></i> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <!-- Quick Stats Cards -->
    <div class="row mb-3">
        <div class="col-sm-6 col-lg-3 mb-2">
            <div class="card card-border shadow-none border">
                <div class="card-body p-3 d-flex align-items-center">
                    <div class="me-3 p-3 rounded text-white" style="background-color: #008080;">
                        <i class="fa-solid fa-file-lines fa-2x"></i>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0 font-smallsize">Total Saved Reports</h6>
                        <h4 class="mb-0 fw-bold">{{ $reports->total() }}</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 mb-2">
            <div class="card card-border shadow-none border">
                <div class="card-body p-3 d-flex align-items-center">
                    <div class="me-3 p-3 rounded text-white" style="background-color: #20b2aa;">
                        <i class="fa-solid fa-database fa-2x"></i>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0 font-smallsize">Available Data Sources</h6>
                        <h4 class="mb-0 fw-bold">{{ count($dataSources) }}</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 mb-2">
            <div class="card card-border shadow-none border">
                <div class="card-body p-3 d-flex align-items-center">
                    <div class="me-3 p-3 rounded text-white" style="background-color: #4682b4;">
                        <i class="fa-solid fa-file-export fa-2x"></i>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0 font-smallsize">Export Formats</h6>
                        <h4 class="mb-0 fw-bold">CSV, Excel, PDF</h4>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-lg-3 mb-2">
            <div class="card card-border shadow-none border">
                <div class="card-body p-3 d-flex align-items-center">
                    <div class="me-3 p-3 rounded text-white" style="background-color: #5c6bc0;">
                        <i class="fa-solid fa-chart-column fa-2x"></i>
                    </div>
                    <div>
                        <h6 class="text-muted mb-0 font-smallsize">Visual Outputs</h6>
                        <h4 class="mb-0 fw-bold">Table, Bar, Line, Pie</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter & Reports Table Card -->
    <div class="card card-border shadow-none border">
        <div class="card-header bg-white py-3 border-bottom d-flex flex-wrap justify-content-between align-items-center">
            <h6 class="mb-0 fw-bold text-dark"><i class="fa-solid fa-folder-open me-2 text-muted"></i>Saved Custom Reports</h6>
            <form action="{{ route('admin.reports.index') }}" method="GET" class="d-flex flex-wrap gap-2 mt-2 mt-md-0">
                <select name="data_source" class="form-select form-select-sm" style="width: auto;" onchange="this.form.submit()">
                    <option value="">All Data Sources</option>
                    @foreach($dataSources as $key => $src)
                        <option value="{{ $key }}" {{ request('data_source') == $key ? 'selected' : '' }}>{{ $src['label'] }}</option>
                    @endforeach
                </select>
                <div class="input-group input-group-sm" style="max-width: 250px;">
                    <input type="text" name="search" class="form-control" placeholder="Search reports..." value="{{ request('search') }}">
                    <button class="btn btn-outline-secondary" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                </div>
                @if(request('search') || request('data_source'))
                    <a href="{{ route('admin.reports.index') }}" class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-xmark"></i></a>
                @endif
            </form>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 50px;">#</th>
                            <th>Report Name</th>
                            <th>Data Source</th>
                            <th>Output Type</th>
                            <th>Created By</th>
                            <th>Created On</th>
                            <th class="text-end" style="min-width: 220px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($reports as $report)
                            @php
                                $cfg = $report->configuration ?? [];
                                $outputType = $cfg['output_type'] ?? 'table';
                                $rawSources = is_array($cfg['data_sources'] ?? null) 
                                    ? $cfg['data_sources'] 
                                    : (str_contains($report->data_source ?? '', ',') ? array_filter(array_map('trim', explode(',', $report->data_source))) : [$report->data_source]);
                                $isMulti = count($rawSources) > 1;
                            @endphp
                            <tr>
                                <td>{{ $loop->iteration + ($reports->currentPage() - 1) * $reports->perPage() }}</td>
                                <td>
                                    <div class="fw-bold text-dark">{{ $report->name }}</div>
                                    @if($report->description)
                                        <div class="text-muted font-smallsize">{{ Str::limit($report->description, 60) }}</div>
                                    @endif
                                </td>
                                <td>
                                    @if($isMulti)
                                        <div>
                                            <span class="badge text-white mb-1" style="background-color: #008080;">
                                                <i class="fa-solid fa-layer-group me-1"></i> Multi-Source ({{ count($rawSources) }})
                                            </span>
                                            <div class="d-flex flex-wrap gap-1 mt-1">
                                                @foreach($rawSources as $sKey)
                                                    @php $sInfo = $dataSources[$sKey] ?? null; @endphp
                                                    <span class="badge bg-light text-dark border font-smallsize" style="font-size: 11px;">
                                                        <i class="{{ $sInfo['icon'] ?? 'fa-solid fa-table' }} me-1 text-teal" style="color: #008080;"></i> {{ $sInfo['label'] ?? ucfirst($sKey) }}
                                                    </span>
                                                @endforeach
                                            </div>
                                        </div>
                                    @else
                                        @php
                                            $sKey = $rawSources[0] ?? $report->data_source;
                                            $sourceInfo = $dataSources[$sKey] ?? null;
                                        @endphp
                                        @if($sourceInfo)
                                            <span class="badge bg-light text-dark border">
                                                <i class="{{ $sourceInfo['icon'] ?? 'fa-solid fa-database' }} me-1 text-teal" style="color: #008080;"></i> {{ $sourceInfo['label'] }}
                                            </span>
                                        @else
                                            <span class="badge bg-secondary">{{ ucfirst($report->data_source) }}</span>
                                        @endif
                                    @endif
                                </td>
                                <td>
                                    @if($outputType === 'bar')
                                        <span class="badge bg-primary"><i class="fa-solid fa-chart-column me-1"></i> Bar Chart</span>
                                    @elseif($outputType === 'line')
                                        <span class="badge bg-info text-dark"><i class="fa-solid fa-chart-line me-1"></i> Line Chart</span>
                                    @elseif($outputType === 'pie')
                                        <span class="badge bg-warning text-dark"><i class="fa-solid fa-chart-pie me-1"></i> Pie Chart</span>
                                    @else
                                        <span class="badge bg-secondary"><i class="fa-solid fa-table me-1"></i> Data Table</span>
                                    @endif
                                </td>
                                <td>{{ $report->creator->first_name ?? 'Admin' }} {{ $report->creator->last_name ?? '' }}</td>
                                <td class="font-smallsize text-muted">{{ $report->created_at ? $report->created_at->format('d M, Y') : '-' }}</td>
                                <td class="text-end">
                                    <div class="btn-group btn-group-sm">
                                        <a href="{{ route('admin.reports.run', $report->id) }}" class="btn btn-sm btn-outline-primary" title="Run / View Report">
                                            <i class="fa-solid fa-play me-1"></i> Run
                                        </a>
                                        <a href="{{ route('admin.reports.edit', $report->id) }}" class="btn btn-sm btn-outline-secondary" title="Edit Configuration">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </a>
                                        <div class="btn-group btn-group-sm" role="group">
                                            <button type="button" class="btn btn-sm btn-outline-success dropdown-toggle report-export-toggle" data-bs-toggle="dropdown" aria-expanded="false" title="Export">
                                                <i class="fa-solid fa-download"></i>
                                            </button>
                                            <ul class="dropdown-menu dropdown-menu-end font-smallsize">
                                                <li>
                                                    <a class="dropdown-item" href="{{ route('admin.reports.export', ['report' => $report->id, 'format' => 'csv']) }}">
                                                        <i class="fa-solid fa-file-csv text-success me-2"></i> Export as CSV
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="{{ route('admin.reports.export', ['report' => $report->id, 'format' => 'excel']) }}">
                                                        <i class="fa-solid fa-file-excel text-success me-2"></i> Export as Excel (.xls)
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="dropdown-item" href="{{ route('admin.reports.export', ['report' => $report->id, 'format' => 'pdf']) }}">
                                                        <i class="fa-solid fa-file-pdf text-danger me-2"></i> Export as PDF
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <form action="{{ route('admin.reports.destroy', $report->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this saved report?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete Report">
                                                <i class="fa-solid fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted">
                                    <i class="fa-solid fa-file-circle-question fa-3x mb-3 text-secondary"></i>
                                    <h5>No reports saved yet</h5>
                                    <p class="font-smallsize mb-3">Click below to start creating your first custom LMS report.</p>
                                    <a href="{{ route('admin.reports.create') }}" class="btn btn-sm btn-primary" style="background-color: #008080; border-color: #008080;">
                                        <i class="fa-solid fa-plus me-1"></i> Create First Report
                                    </a>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

        @if($reports->hasPages())
            <div class="card-footer bg-white py-2 border-top">
                <div class="d-flex justify-content-between align-items-center">
                    <small class="text-muted">Showing {{ $reports->firstItem() }} to {{ $reports->lastItem() }} of {{ $reports->total() }} reports</small>
                    {{ $reports->links() }}
                </div>
            </div>
        @endif
    </div>
</div>

@include('layouts.admin.footer')

<script>
    document.querySelectorAll('.report-export-toggle').forEach(function (button) {
        new bootstrap.Dropdown(button, {
            popperConfig: function (defaultConfig) {
                return Object.assign({}, defaultConfig, {
                    // Escape the responsive table's overflow without removing its scrollbar.
                    strategy: 'fixed',
                    modifiers: defaultConfig.modifiers.concat([{
                        name: 'preventOverflow',
                        options: {
                            boundary: document.body,
                            rootBoundary: 'viewport'
                        }
                    }])
                });
            }
        });
    });
</script>
