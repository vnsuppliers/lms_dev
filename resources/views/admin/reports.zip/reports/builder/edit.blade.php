@include('layouts.admin.header')

@php
    $config = is_array($report->configuration) ? $report->configuration : (json_decode($report->configuration, true) ?? []);
    $rawSavedSources = $config['data_sources'] ?? null;
    if (empty($rawSavedSources)) {
        if (!empty($report->data_source) && str_contains($report->data_source, ',')) {
            $rawSavedSources = array_filter(array_map('trim', explode(',', $report->data_source)));
        } else {
            $rawSavedSources = [$report->data_source ?? ($config['data_source'] ?? 'learners')];
        }
    }
    $savedSources = is_array($rawSavedSources) ? array_values($rawSavedSources) : ['learners'];
    if (empty($savedSources)) {
        $savedSources = ['learners'];
    }

    $savedDatePreset = $config['date_preset'] ?? 'all';
    $savedDateFrom = $config['date_from'] ?? '';
    $savedDateTo = $config['date_to'] ?? '';
    $savedStatus = $config['status_filter'] ?? 'all';
    $savedLearner = $config['learner_filter'] ?? 'all';
    $savedCourse = $config['course_filter'] ?? 'all';

    $savedFields = array_values(array_filter($config['fields'] ?? ($config['selected_fields'] ?? []), function($k) {
        return $k === 'users.emp_id' || (!str_ends_with($k, '.id') && !str_ends_with($k, '_id'));
    }));
    $savedSortField = $config['sort_field'] ?? '';
    $savedSortDirection = $config['sort_direction'] ?? 'desc';
    $savedAssessmentName = $config['assessment_name_filter'] ?? '';
    $savedAssessmentAssign = $config['assessment_assignment_filter'] ?? 'Total';
    $savedCertStatus = $config['certificate_status_filter'] ?? 'All';
    $savedFeedbackType = $config['feedback_type_filter'] ?? 'Total';
    $savedVideoType = $config['video_type_filter'] ?? 'All';
    $savedVideoWatch = $config['video_watch_filter'] ?? 'Total';
    $savedExamResult = $config['exam_result_filter'] ?? 'Total';
@endphp

<div class="container-fluid py-3">
    <!-- Header -->
    <div class="row mb-3 align-items-center">
        <div class="col-md-6">
            <h4 class="mb-1 text-dark fw-bold"><i class="fa-solid fa-sliders text-teal me-2" style="color: #008080;"></i>Edit Report Builder: {{ $report->name }}</h4>
            <p class="text-muted mb-0 font-smallsize">Configure custom query rules, filters, grouping, calculations and visualization.</p>
        </div>
        <div class="col-md-6 text-md-end mt-2 mt-md-0">
            <a href="{{ route('admin.reports.index') }}" class="btn btn-outline-secondary btn-sm">
                <i class="fa-solid fa-arrow-left me-1"></i> Back to Saved Reports
            </a>
        </div>
    </div>

    <!-- Builder Form Card -->
    <div class="card card-border shadow-none border mb-4">
        <div class="card-body p-4">
            <form id="reportBuilderForm">
                @csrf
                @method('PUT')
                <div id="orderedFieldsContainer" style="display:none;"></div>

                <!-- STEP 1: Select Data Sources -->
                <div class="mb-4 pb-3 border-bottom">
                    <div class="d-flex flex-wrap align-items-center justify-content-between mb-3">
                        <div class="d-flex align-items-center">
                            <span class="badge rounded-circle p-2 me-2 text-white" style="background-color: #008080; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">1</span>
                            <div>
                                <h5 class="mb-0 fw-bold text-dark">Select Data Sources <span class="badge ms-2 px-2 py-1 font-smallsize text-white" id="selectedSourcesBadge" style="background-color: #008080;">{{ count($savedSources) }} {{ count($savedSources) === 1 ? 'Source Selected' : 'Sources Selected' }}</span></h5>
                                <small class="text-muted">Select one or multiple related data sources to build a complete cross-functional report.</small>
                            </div>
                        </div>
                        <div class="mt-2 mt-sm-0">
                            <button type="button" class="btn btn-xs btn-outline-teal me-1" id="btnSelectAllSources" style="color: #008080; border-color: #008080;">
                                <i class="fa-solid fa-check-double me-1"></i> Select All Sources
                            </button>
                            <button type="button" class="btn btn-xs btn-outline-secondary" id="btnClearAllSources">
                                <i class="fa-solid fa-rotate-left me-1"></i> Reset Selection
                            </button>
                        </div>
                    </div>
                    <div class="row g-2">
                        @foreach($dataSources as $key => $src)
                            <div class="col-md-4 col-sm-6 mb-2">
                                <label class="card h-100 border p-3 cursor-pointer source-card {{ in_array($key, $savedSources) ? 'border-teal bg-light shadow-sm' : '' }}" style="cursor: pointer; transition: all 0.2s ease;">
                                    <div class="d-flex align-items-center">
                                        <input type="checkbox" name="data_sources[]" value="{{ $key }}" class="form-check-input me-3 source-checkbox" {{ in_array($key, $savedSources) ? 'checked' : '' }}>
                                        <div>
                                            <h6 class="mb-1 fw-bold text-dark"><i class="{{ $src['icon'] ?? 'fa-solid fa-database' }} me-2 text-teal" style="color: #008080;"></i>{{ $src['label'] }}</h6>
                                            <p class="text-muted mb-0 font-smallsize">{{ $src['description'] }}</p>
                                        </div>
                                    </div>
                                </label>
                            </div>
                        @endforeach
                    </div>
                </div>

                <!-- STEP 2: Select Fields -->
                <div class="mb-4 pb-3 border-bottom">
                    <div class="d-flex flex-wrap align-items-center justify-content-between mb-3">
                        <div class="d-flex align-items-center">
                            <span class="badge rounded-circle p-2 me-2 text-white" style="background-color: #008080; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">2</span>
                            <div>
                                <h5 class="mb-0 fw-bold text-dark">Select Columns to Display <span class="badge bg-secondary ms-2 px-2 py-1 font-smallsize" id="selectedColumnsCount">0 columns selected</span></h5>
                                <small class="text-muted">Columns are organized by data source. <span class="text-dark fw-semibold"><i class="fa-solid fa-arrow-down-1-9 text-teal me-1" style="color: #008080;"></i>Selection order determines column position (#1, #2, #3...)</span> in Preview & Download.</small>
                            </div>
                        </div>
                        <div class="d-flex align-items-center gap-2 mt-2 mt-sm-0">
                            <div class="input-group input-group-sm" style="width: 250px;">
                                <span class="input-group-text bg-white border-teal text-teal" style="color: #008080;"><i class="fa-solid fa-magnifying-glass"></i></span>
                                <input type="text" id="columnSearchInput" class="form-control border-teal" placeholder="Search columns..." autocomplete="off">
                            </div>
                            <button type="button" class="btn btn-xs btn-outline-secondary" id="selectAllFields">Select All</button>
                            <button type="button" class="btn btn-xs btn-outline-secondary" id="deselectAllFields">Deselect All</button>
                        </div>
                    </div>
                    <div id="fieldsContainer">
                        <div class="text-center py-3 text-muted"><i class="fa-solid fa-spinner fa-spin me-2"></i> Loading fields...</div>
                    </div>
                </div>

                <!-- STEP 3: Simple & Smart Filters -->
                <div class="mb-4 pb-3 border-bottom">
                    <div class="d-flex align-items-center mb-3">
                        <div>
                            <div class="d-flex align-items-center">
                                <span class="badge rounded-circle p-2 me-2 text-white" style="background-color: #008080; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">3</span>
                                <h5 class="mb-0 fw-bold text-dark">Filter Records (Optional)</h5>
                            </div>
                            <small class="text-muted ms-4">Filter records by status, keyword, or date range.</small>
                        </div>
                    </div>

                    <!-- Universal Quick Filter Bar (Filter by Specific Learner, Course, Date Range & Status) -->
                    <div id="universalQuickFilterWrapper" class="p-3 mb-3 border rounded bg-light">
                        <div class="row g-3 align-items-center mb-2">
                            <!-- Filter by Specific Learner / User with Embedded Search Dropdown -->
                            <div class="col-md-6">
                                <label class="form-label font-smallsize fw-bold text-dark mb-1">
                                    <i class="fa-solid fa-user text-teal me-1" style="color: #008080;"></i> Filter by Specific Learner / User:
                                </label>
                                <div class="position-relative" id="learnerFilterDropdownWrapper">
                                    <button type="button" class="form-select form-select-sm border-teal text-start d-flex justify-content-between align-items-center w-100 shadow-sm" id="learnerFilterBtn" style="background-color: #ffffff; cursor: pointer; min-height: 38px;">
                                        <span id="selectedLearnerLabel" class="text-truncate fw-semibold text-dark"><i class="fa-solid fa-users me-1 text-teal" style="color: #008080;"></i> All Learners (Everyone)</span>
                                        <i class="fa-solid fa-chevron-down ms-2 text-muted" style="font-size: 11px;"></i>
                                    </button>
                                    <input type="hidden" name="learner_filter" id="universalLearnerFilter" value="{{ $savedLearner }}">
                                    
                                    <!-- Embedded Search Dropdown Menu -->
                                    <div class="custom-dropdown-menu shadow-lg border rounded p-2 bg-white d-none position-absolute w-100" id="learnerDropdownMenu" style="top: 100%; left: 0; z-index: 1050; margin-top: 4px; box-shadow: 0 10px 25px rgba(0,0,0,0.15) !important; border-color: #008080 !important;">
                                        <div class="p-1 mb-2 border-bottom bg-light rounded">
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-text bg-white border-teal text-teal" style="color: #008080;"><i class="fa-solid fa-magnifying-glass"></i></span>
                                                <input type="text" id="learnerSearchInput" class="form-control border-teal" placeholder="Type name, email, or emp ID to search..." autocomplete="off">
                                                <button type="button" class="btn btn-outline-secondary btn-sm" id="clearLearnerSearch" title="Clear search"><i class="fa-solid fa-xmark"></i></button>
                                            </div>
                                        </div>
                                        <div id="learnerOptionsList" style="overflow-y: auto; max-height: 250px;">
                                            <div class="text-center py-2 text-muted font-smallsize"><i class="fa-solid fa-spinner fa-spin me-1"></i> Loading learners...</div>
                                        </div>
                                    </div>
                                </div>
                                <small class="text-muted font-smallsize">Click dropdown and type in the search box to filter by learner name or email.</small>
                            </div>

                            <!-- Filter by Specific Course with Embedded Search Dropdown -->
                            <div class="col-md-6" id="universalCourseCol">
                                <label class="form-label font-smallsize fw-bold text-dark mb-1">
                                    <i class="fa-solid fa-book text-teal me-1" style="color: #008080;"></i> Filter by Specific Course:
                                </label>
                                <div class="position-relative" id="courseFilterDropdownWrapper">
                                    <button type="button" class="form-select form-select-sm border-teal text-start d-flex justify-content-between align-items-center w-100 shadow-sm" id="courseFilterBtn" style="background-color: #ffffff; cursor: pointer; min-height: 38px;">
                                        <span id="selectedCourseLabel" class="text-truncate fw-semibold text-dark"><i class="fa-solid fa-book me-1 text-teal" style="color: #008080;"></i> All Courses</span>
                                        <i class="fa-solid fa-chevron-down ms-2 text-muted" style="font-size: 11px;"></i>
                                    </button>
                                    <input type="hidden" name="course_filter" id="universalCourseFilter" value="{{ $savedCourse }}">
                                    
                                    <!-- Embedded Search Dropdown Menu -->
                                    <div class="custom-dropdown-menu shadow-lg border rounded p-2 bg-white d-none position-absolute w-100" id="courseDropdownMenu" style="top: 100%; left: 0; z-index: 1050; margin-top: 4px; box-shadow: 0 10px 25px rgba(0,0,0,0.15) !important; border-color: #008080 !important;">
                                        <div class="p-1 mb-2 border-bottom bg-light rounded">
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-text bg-white border-teal text-teal" style="color: #008080;"><i class="fa-solid fa-magnifying-glass"></i></span>
                                                <input type="text" id="courseSearchInput" class="form-control border-teal" placeholder="Type course name or code to search..." autocomplete="off">
                                                <button type="button" class="btn btn-outline-secondary btn-sm" id="clearCourseSearch" title="Clear search"><i class="fa-solid fa-xmark"></i></button>
                                            </div>
                                        </div>
                                        <div id="courseOptionsList" style="overflow-y: auto; max-height: 250px;">
                                            <div class="text-center py-2 text-muted font-smallsize"><i class="fa-solid fa-spinner fa-spin me-1"></i> Loading courses...</div>
                                        </div>
                                    </div>
                                </div>
                                <small class="text-muted font-smallsize">Click dropdown and type in the search box to filter by course title.</small>
                            </div>
                        </div>

                        <!-- Date Range Presets & Universal Status Filter Row -->
                        <div class="row g-2 align-items-end pt-2 border-top">
                            <!-- Quick Date Presets -->
                            <div class="col-md-3">
                                <label class="form-label font-smallsize fw-bold text-dark mb-1">
                                    <i class="fa-regular fa-calendar text-teal me-1" style="color: #008080;"></i> Date Range Preset:
                                </label>
                                <select name="date_preset" id="datePresetFilter" class="form-select form-select-sm border-teal" style="min-height: 36px;">
                                    <option value="all" {{ $savedDatePreset === 'all' ? 'selected' : '' }}>All Time (No Date Filter)</option>
                                    <option value="today" {{ $savedDatePreset === 'today' ? 'selected' : '' }}>Today</option>
                                    <option value="yesterday" {{ $savedDatePreset === 'yesterday' ? 'selected' : '' }}>Yesterday</option>
                                    <option value="last_7_days" {{ $savedDatePreset === 'last_7_days' ? 'selected' : '' }}>Last 7 Days</option>
                                    <option value="last_30_days" {{ $savedDatePreset === 'last_30_days' ? 'selected' : '' }}>Last 30 Days</option>
                                    <option value="this_month" {{ $savedDatePreset === 'this_month' ? 'selected' : '' }}>This Month</option>
                                    <option value="last_month" {{ $savedDatePreset === 'last_month' ? 'selected' : '' }}>Last Month</option>
                                    <option value="last_3_months" {{ $savedDatePreset === 'last_3_months' ? 'selected' : '' }}>Last 3 Months</option>
                                    <option value="this_year" {{ $savedDatePreset === 'this_year' ? 'selected' : '' }}>This Year</option>
                                    <option value="custom" {{ $savedDatePreset === 'custom' ? 'selected' : '' }}>Custom Date Range...</option>
                                </select>
                            </div>

                            <!-- From Date -->
                            <div class="col-md-3">
                                <label class="form-label font-smallsize fw-bold text-dark mb-1">
                                    <i class="fa-regular fa-calendar-days text-teal me-1" style="color: #008080;"></i> From Date:
                                </label>
                                <input type="date" name="date_from" id="dateFromFilter" class="form-control form-control-sm border-teal" value="{{ $savedDateFrom }}" style="min-height: 36px;">
                            </div>

                            <!-- To Date -->
                            <div class="col-md-3">
                                <label class="form-label font-smallsize fw-bold text-dark mb-1">
                                    <i class="fa-regular fa-calendar-check text-teal me-1" style="color: #008080;"></i> To Date:
                                </label>
                                <input type="date" name="date_to" id="dateToFilter" class="form-control form-control-sm border-teal" value="{{ $savedDateTo }}" style="min-height: 36px;">
                            </div>

                            <!-- Status / Result Filter -->
                            <div class="col-md-3">
                                <label class="form-label font-smallsize fw-bold text-dark mb-1" id="universalStatusFilterLabel">
                                    <i class="fa-solid fa-list-check text-teal me-1" style="color: #008080;"></i> Course Status:
                                </label>
                                <select name="status_filter" id="universalStatusFilter" class="form-select form-select-sm border-teal" style="min-height: 36px;">
                                    <option value="all" {{ $savedStatus === 'all' ? 'selected' : '' }}>All Statuses</option>
                                    <option value="in_progress" {{ $savedStatus === 'in_progress' || $savedStatus === 'incomplete' ? 'selected' : '' }}>In Progress</option>
                                    <option value="completed" {{ $savedStatus === 'completed' ? 'selected' : '' }}>Completed</option>
                                    <option value="not_started" {{ $savedStatus === 'not_started' ? 'selected' : '' }}>Not Started</option>
                                    <option value="expired" {{ $savedStatus === 'expired' ? 'selected' : '' }}>Expired</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Dedicated Standalone Dropdowns for Course Assessments -->
                    <div id="assessmentDedicatedFilterWrapper" class="p-3 mb-3 border rounded bg-light d-none">
                        <div class="row g-3 align-items-center">
                            <div class="col-md-6">
                                <label class="form-label font-smallsize fw-bold text-dark mb-1">
                                    <i class="fa-solid fa-magnifying-glass text-teal me-1" style="color: #008080;"></i> Assessment Name:
                                </label>
                                <input type="text" name="assessment_name_filter" id="assessmentNameFilter" class="form-control form-control-sm border-teal" placeholder="Search assessment..." value="{{ $savedAssessmentName }}">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label font-smallsize fw-bold text-dark mb-1">
                                    <i class="fa-solid fa-filter text-teal me-1" style="color: #008080;"></i> Assignment Type:
                                </label>
                                <select name="assessment_assignment_filter" id="assessmentQuickFilter" class="form-select form-select-sm border-teal">
                                    <option value="Total" {{ $savedAssessmentAssign === 'Total' ? 'selected' : '' }}>Total (All)</option>
                                    <option value="Assigned" {{ $savedAssessmentAssign === 'Assigned' ? 'selected' : '' }}>Assigned Only</option>
                                    <option value="Reassigned" {{ $savedAssessmentAssign === 'Reassigned' ? 'selected' : '' }}>Reassigned Only</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Dedicated Standalone Dropdown for Certificates -->
                    <div id="certificatesDedicatedFilterWrapper" class="p-3 mb-3 border rounded bg-light d-none">
                        <div class="row align-items-center">
                            <div class="col-md-6 col-lg-5">
                                <label class="form-label font-smallsize fw-bold text-dark mb-1">
                                    <i class="fa-solid fa-filter text-teal me-1" style="color: #008080;"></i> Certificate Status Filter:
                                </label>
                                <select name="certificate_status_filter" id="certificateStatusQuickFilter" class="form-select form-select-sm border-teal">
                                    <option value="All" {{ $savedCertStatus === 'All' ? 'selected' : '' }}>All (Active & Inactive)</option>
                                    <option value="1" {{ (string)$savedCertStatus === '1' ? 'selected' : '' }}>Active Only</option>
                                    <option value="0" {{ (string)$savedCertStatus === '0' ? 'selected' : '' }}>Inactive Only</option>
                                </select>
                            </div>
                            <div class="col-md-6 col-lg-7">
                                <small class="text-muted font-smallsize d-block mt-2 mt-md-0">
                                    <i class="fa-solid fa-circle-info text-teal me-1" style="color: #008080;"></i> 
                                    Switch easily between <strong>All</strong> (default), <strong>Active</strong>, or <strong>Inactive</strong> certificates.
                                </small>
                            </div>
                        </div>
                    </div>

                    <!-- Dedicated Standalone Dropdown for Ratings & Feedback -->
                    <div id="feedbackDedicatedFilterWrapper" class="p-3 mb-3 border rounded bg-light d-none">
                        <div class="row align-items-center">
                            <div class="col-md-6 col-lg-5">
                                <label class="form-label font-smallsize fw-bold text-dark mb-1">
                                    <i class="fa-solid fa-filter text-teal me-1" style="color: #008080;"></i> Feedback & Ratings Filter (Total / Overall / Category):
                                </label>
                                <select name="feedback_type_filter" id="feedbackTypeQuickFilter" class="form-select form-select-sm border-teal">
                                    <option value="Total" {{ $savedFeedbackType === 'Total' ? 'selected' : '' }}>Total (All Overall & Category)</option>
                                    <option value="Overall" {{ $savedFeedbackType === 'Overall' ? 'selected' : '' }}>Overall (Global Feedback)</option>
                                    <option value="Category" {{ $savedFeedbackType === 'Category' ? 'selected' : '' }}>Category (Course / Category Specific)</option>
                                </select>
                            </div>
                            <div class="col-md-6 col-lg-7">
                                <small class="text-muted font-smallsize d-block mt-2 mt-md-0">
                                    <i class="fa-solid fa-circle-info text-teal me-1" style="color: #008080;"></i> 
                                    Filter easily between <strong>Total</strong> (default), <strong>Overall</strong>, or <strong>Category</strong> ratings & feedback.
                                </small>
                            </div>
                        </div>
                    </div>

                    <!-- Dedicated Standalone Dropdown for Videos -->
                    <div id="videosDedicatedFilterWrapper" class="p-3 mb-3 border rounded bg-light d-none">
                        <div class="row g-3 align-items-center">
                            <div class="col-md-6">
                                <label class="form-label font-smallsize fw-bold text-dark mb-1">
                                    <i class="fa-solid fa-photo-film text-teal me-1" style="color: #008080;"></i> Video & Content Type:
                                </label>
                                <select name="video_type_filter" id="videoTypeQuickFilter" class="form-select form-select-sm border-teal">
                                    <option value="All" {{ $savedVideoType === 'All' ? 'selected' : '' }}>All Content Types (Amazon, YouTube, Local, SCORM, Attachments)</option>
                                    <option value="1" {{ (string)$savedVideoType === '1' || strtolower((string)$savedVideoType) === 'amazon' ? 'selected' : '' }}>Amazon</option>
                                    <option value="2" {{ (string)$savedVideoType === '2' || strtolower((string)$savedVideoType) === 'youtube' ? 'selected' : '' }}>YouTube</option>
                                    <option value="3" {{ (string)$savedVideoType === '3' || strtolower((string)$savedVideoType) === 'local' ? 'selected' : '' }}>Local</option>
                                    <option value="4" {{ (string)$savedVideoType === '4' || strtolower((string)$savedVideoType) === 'scorm' ? 'selected' : '' }}>SCORM</option>
                                    <option value="5" {{ (string)$savedVideoType === '5' || strtolower((string)$savedVideoType) === 'attachments' || strtolower((string)$savedVideoType) === 'attachment' ? 'selected' : '' }}>Attachments</option>
                                </select>
                                <small class="text-muted font-smallsize d-block mt-1">
                                    Quick filter for <strong>Amazon</strong>, <strong>YouTube</strong>, <strong>Local</strong>, <strong>SCORM</strong>, or <strong>Attachments</strong>.
                                </small>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label font-smallsize fw-bold text-dark mb-1">
                                    <i class="fa-solid fa-circle-check text-teal me-1" style="color: #008080;"></i> Video Watch Status (Total / Watched / Not Watched):
                                </label>
                                <select name="video_watch_filter" id="videoWatchQuickFilter" class="form-select form-select-sm border-teal">
                                    <option value="Total" {{ $savedVideoWatch === 'Total' ? 'selected' : '' }}>Total (All Watched & Not Watched)</option>
                                    <option value="Watched" {{ $savedVideoWatch === 'Watched' ? 'selected' : '' }}>Watched (Completed Videos)</option>
                                    <option value="Not Watched" {{ $savedVideoWatch === 'Not Watched' ? 'selected' : '' }}>Not Watched (Pending Videos)</option>
                                </select>
                                <small class="text-muted font-smallsize d-block mt-1">
                                    Filter easily between <strong>Total</strong>, <strong>Watched</strong>, or <strong>Not Watched</strong> video content.
                                </small>
                            </div>
                        </div>
                    </div>

                    <!-- Dedicated Standalone Dropdown for Assignment Exams -->
                    <div id="examsDedicatedFilterWrapper" class="p-3 mb-3 border rounded bg-light d-none">
                        <div class="row align-items-center">
                            <div class="col-md-6 col-lg-5">
                                <label class="form-label font-smallsize fw-bold text-dark mb-1">
                                    <i class="fa-solid fa-file-pen text-teal me-1" style="color: #008080;"></i> Exam Result Filter (Total / Passed / Failed / Pending / Not Attempted):
                                </label>
                                <select name="exam_result_filter" id="examResultQuickFilter" class="form-select form-select-sm border-teal">
                                    <option value="Total" {{ $savedExamResult === 'Total' ? 'selected' : '' }}>Total (All Attempts & Records)</option>
                                    <option value="Passed" {{ $savedExamResult === 'Passed' ? 'selected' : '' }}>Passed (Successful Attempts)</option>
                                    <option value="Failed" {{ $savedExamResult === 'Failed' ? 'selected' : '' }}>Failed (Unsuccessful Attempts)</option>
                                    <option value="Pending" {{ $savedExamResult === 'Pending' ? 'selected' : '' }}>Pending Evaluation</option>
                                    <option value="Not Attempted" {{ $savedExamResult === 'Not Attempted' ? 'selected' : '' }}>Not Attempted</option>
                                </select>
                            </div>
                            <div class="col-md-6 col-lg-7">
                                <small class="text-muted font-smallsize d-block mt-2 mt-md-0">
                                    <i class="fa-solid fa-circle-info text-teal me-1" style="color: #008080;"></i> 
                                    Filter easily between <strong>Total</strong> (default), <strong>Passed</strong>, <strong>Failed</strong>, <strong>Pending Evaluation</strong>, or <strong>Not Attempted</strong> assignment exams.
                                </small>
                            </div>
                        </div>
                    </div>

                    <div id="filtersContainer" class="d-none"></div>
                </div>

                <!-- STEP 4: Sorting Options -->
                <div class="mb-4 pb-3 border-bottom">
                    <div class="d-flex align-items-center mb-3">
                        <span class="badge rounded-circle p-2 me-2 text-white" style="background-color: #008080; width: 28px; height: 28px; display: inline-flex; align-items: center; justify-content: center;">4</span>
                        <h5 class="mb-0 fw-bold text-dark">Sort Records (Optional)</h5>
                    </div>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label font-smallsize fw-bold">Order By Column</label>
                            <select name="sort_field" id="sortFieldSelect" class="form-select form-select-sm">
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label font-smallsize fw-bold">Order Direction</label>
                            <select name="sort_direction" class="form-select form-select-sm">
                                <option value="desc" {{ $savedSortDirection === 'desc' ? 'selected' : '' }}>Newest / Highest First</option>
                                <option value="asc" {{ $savedSortDirection === 'asc' ? 'selected' : '' }}>Oldest / A-Z First</option>
                            </select>
                        </div>
                    </div>
                    <input type="hidden" name="output_type" id="outputTypeInput" value="table">
                </div>

                <!-- Action Buttons: Preview & Save -->
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <button type="button" class="btn btn-primary px-4" id="btnPreview" style="background-color: #008080; border-color: #008080;">
                            <i class="fa-solid fa-eye me-1"></i> Live Preview
                        </button>
                    </div>
                    <div>
                        <button type="button" class="btn btn-success px-4" id="btnOpenSaveModal">
                            <i class="fa-solid fa-floppy-disk me-1"></i> Update Report
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- PREVIEW RESULTS SECTION -->
    <div class="card card-border shadow-none border d-none" id="previewCard">
        <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div class="d-flex align-items-center flex-wrap gap-2">
                <h6 class="mb-0 fw-bold text-dark"><i class="fa-solid fa-table-list me-2 text-teal" style="color: #008080;"></i>Report Preview (<span id="previewCount">0</span> records)</h6>
            </div>
            <div class="d-flex align-items-center gap-2">
                <div class="dropdown">
                    <button class="btn btn-sm btn-outline-success dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-solid fa-download me-1"></i> Export Preview
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end shadow-sm border">
                        <li>
                            <a class="dropdown-item btn-export-preview" href="javascript:void(0);" data-format="csv">
                                <i class="fa-solid fa-file-csv text-success me-2"></i> CSV (.csv)
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item btn-export-preview" href="javascript:void(0);" data-format="excel">
                                <i class="fa-solid fa-file-excel text-success me-2"></i> Excel (.xls)
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item btn-export-preview" href="javascript:void(0);" data-format="pdf">
                                <i class="fa-solid fa-file-pdf text-danger me-2"></i> PDF (Print Landscape)
                            </a>
                        </li>
                    </ul>
                </div>
                <button type="button" class="btn btn-xs btn-outline-secondary" onclick="$('#previewCard').addClass('d-none');">
                    <i class="fa-solid fa-xmark"></i> Close Preview
                </button>
            </div>
        </div>
        <div class="card-body p-3">
            <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
            <style>
                #previewTable {
                    min-width: 100%;
                    border-collapse: separate;
                    border-spacing: 0;
                    border: 1px solid #d1d5db;
                    background-color: #ffffff !important;
                }
                #previewTable thead th,
                #previewTable thead tr,
                #previewTable thead th:hover,
                #previewTable thead tr:hover,
                #previewTable thead tr:hover > th {
                    position: sticky;
                    top: 0;
                    z-index: 10;
                    background: linear-gradient(135deg, #008080 0%, #006666 100%) !important;
                    background-color: #008080 !important;
                    color: #ffffff !important;
                    font-weight: 600 !important;
                    font-size: 13px !important;
                    padding: 12px 14px !important;
                    border: 1px solid #005555 !important;
                    box-shadow: inset 0 1px 0 rgba(255,255,255,0.1), inset 0 -1px 0 rgba(0,0,0,0.15) !important;
                    white-space: nowrap !important;
                    vertical-align: middle !important;
                    letter-spacing: 0.2px;
                }
                #previewTable td {
                    vertical-align: top !important;
                    padding: 10px 14px !important;
                    font-size: 13px !important;
                    line-height: 1.5 !important;
                    border: 1px solid #e5e7eb !important;
                    color: #1f2937 !important;
                    background-color: #ffffff !important;
                }
                #previewTable tbody tr,
                #previewTable tbody td {
                    background-color: #ffffff !important;
                    background: #ffffff !important;
                    color: #1f2937 !important;
                }
                #previewTable tbody tr:hover,
                #previewTable tbody tr:hover > td,
                #previewTable tbody td:hover {
                    background-color: #ffffff !important;
                    background: #ffffff !important;
                    color: #1f2937 !important;
                    box-shadow: none !important;
                    --bs-table-accent-bg: transparent !important;
                    --bs-table-bg-state: transparent !important;
                    --bs-table-hover-bg: transparent !important;
                }
                #previewTable .line-item-entry {
                    padding: 3px 0;
                    min-height: 28px;
                }
                #previewTable .line-item-entry + .line-item-entry {
                    border-top: 1px dashed #e2e8f0;
                    margin-top: 4px;
                    padding-top: 4px;
                }

                /* Custom Searchable Dropdown Styling */
                .custom-dropdown-menu {
                    background-color: #ffffff !important;
                    border: 1.5px solid #008080 !important;
                    border-radius: 6px !important;
                    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.18) !important;
                    z-index: 1060 !important;
                }
                .dropdown-item-custom, .dropdown-course-item {
                    transition: all 0.15s ease;
                    border-radius: 4px;
                    padding: 8px 10px;
                    margin-bottom: 2px;
                }
                .dropdown-item-custom:hover, .dropdown-course-item:hover {
                    background-color: #e0f2f1 !important;
                }
                .dropdown-item-custom.active-item, .dropdown-course-item.active-item {
                    background-color: #008080 !important;
                    color: #ffffff !important;
                }
                .dropdown-item-custom.active-item .text-dark,
                .dropdown-item-custom.active-item .text-muted,
                .dropdown-course-item.active-item .text-dark,
                .dropdown-course-item.active-item .text-muted {
                    color: #ffffff !important;
                }
            </style>
            <div id="chartPreviewWrapper" class="mb-4 d-none" style="max-height: 380px; position: relative;">
                <canvas id="previewChart" height="120"></canvas>
            </div>

            <div class="table-responsive" style="min-height: 520px; max-height: 85vh; overflow-y: auto;">
                <table class="table table-bordered align-top mb-0 font-smallsize" id="previewTable">
                    <thead id="previewThead"></thead>
                    <tbody id="previewTbody"></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- SAVE REPORT MODAL -->
<div class="modal fade" id="saveReportModal" tabindex="-1" aria-labelledby="saveReportModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title fw-bold" id="saveReportModalLabel"><i class="fa-solid fa-pen-to-square text-teal me-2" style="color: #008080;"></i>Update Saved Report</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label fw-bold font-smallsize">Report Name <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="saveReportName" placeholder="e.g. Monthly Completed Enrollments by Department" value="{{ $report->name }}" required>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold font-smallsize">Description (Optional)</label>
                    <textarea class="form-control" id="saveReportDesc" rows="3" placeholder="Brief summary of what this report is for...">{{ $report->description }}</textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary btn-sm" id="btnConfirmSave" style="background-color: #008080; border-color: #008080;">
                    <i class="fa-solid fa-check me-1"></i> Update Report
                </button>
            </div>
        </div>
    </div>
</div>

<!-- JAVASCRIPT FOR REPORT BUILDER -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
$(document).ready(function () {
    let currentSchema = null;
    let chartInstance = null;
    let filterIndex = 0;
    let isInitialLoad = true;
    let savedFields = @json($savedFields);
    let savedSortField = "{{ $savedSortField }}";
    let savedDynamicFilters = @json($config['filters'] ?? []);
    let selectedFieldsOrder = Array.isArray(savedFields) && savedFields.length > 0 ? savedFields.slice() : [];

    // Toggle Learner Dropdown
    $(document).on('click', '#learnerFilterBtn', function (e) {
        e.stopPropagation();
        $('#courseDropdownMenu').addClass('d-none');
        $('#learnerDropdownMenu').toggleClass('d-none');
        if (!$('#learnerDropdownMenu').hasClass('d-none')) {
            setTimeout(function () { $('#learnerSearchInput').focus(); }, 100);
        }
    });

    // Toggle Course Dropdown
    $(document).on('click', '#courseFilterBtn', function (e) {
        e.stopPropagation();
        $('#learnerDropdownMenu').addClass('d-none');
        $('#courseDropdownMenu').toggleClass('d-none');
        if (!$('#courseDropdownMenu').hasClass('d-none')) {
            setTimeout(function () { $('#courseSearchInput').focus(); }, 100);
        }
    });

    // Prevent closing when clicking inside dropdown menu
    $(document).on('click', '#learnerDropdownMenu, #courseDropdownMenu', function (e) {
        e.stopPropagation();
    });

    // Close when clicking outside
    $(document).on('click', function () {
        $('#learnerDropdownMenu').addClass('d-none');
        $('#courseDropdownMenu').addClass('d-none');
    });

    // Search Filter inside Learner Dropdown
    $(document).on('input', '#learnerSearchInput', function () {
        let q = $(this).val().toLowerCase().trim();
        let matches = 0;
        $('#learnerOptionsList .dropdown-item-custom').each(function () {
            let isAll = $(this).data('value') === 'all';
            let searchIndex = ($(this).data('search') || '').toString();
            if (isAll || searchIndex.indexOf(q) !== -1) {
                $(this).removeClass('d-none');
                matches++;
            } else {
                $(this).addClass('d-none');
            }
        });
        if (matches === 0) {
            if ($('#noLearnerMatch').length === 0) {
                $('#learnerOptionsList').append('<div id="noLearnerMatch" class="text-center py-3 text-muted font-smallsize"><i class="fa-solid fa-circle-exclamation me-1 text-warning"></i> No learners found matching "' + q + '"</div>');
            }
        } else {
            $('#noLearnerMatch').remove();
        }
    });

    $(document).on('click', '#clearLearnerSearch', function () {
        $('#learnerSearchInput').val('').trigger('input').focus();
    });

    // Search Filter inside Course Dropdown
    $(document).on('input', '#courseSearchInput', function () {
        let q = $(this).val().toLowerCase().trim();
        let matches = 0;
        $('#courseOptionsList .dropdown-course-item').each(function () {
            let isAll = $(this).data('value') === 'all';
            let searchIndex = ($(this).data('search') || '').toString();
            if (isAll || searchIndex.indexOf(q) !== -1) {
                $(this).removeClass('d-none');
                matches++;
            } else {
                $(this).addClass('d-none');
            }
        });
        if (matches === 0) {
            if ($('#noCourseMatch').length === 0) {
                $('#courseOptionsList').append('<div id="noCourseMatch" class="text-center py-3 text-muted font-smallsize"><i class="fa-solid fa-circle-exclamation me-1 text-warning"></i> No courses found matching "' + q + '"</div>');
            }
        } else {
            $('#noCourseMatch').remove();
        }
    });

    $(document).on('click', '#clearCourseSearch', function () {
        $('#courseSearchInput').val('').trigger('input').focus();
    });

    // Select Learner Item
    $(document).on('click', '.dropdown-item-custom', function () {
        let val = $(this).data('value');
        let label = $(this).data('label');
        $('#universalLearnerFilter').val(val);
        $('#selectedLearnerLabel').html(val === 'all' ? '<i class="fa-solid fa-users me-1 text-teal" style="color: #008080;"></i> All Learners (Everyone)' : '<i class="fa-solid fa-user me-1 text-teal" style="color: #008080;"></i> ' + label);
        $('#learnerOptionsList .dropdown-item-custom').removeClass('active-item');
        $(this).addClass('active-item');
        $('#learnerDropdownMenu').addClass('d-none');
    });

    // Select Course Item
    $(document).on('click', '.dropdown-course-item', function () {
        let val = $(this).data('value');
        let label = $(this).data('label');
        $('#universalCourseFilter').val(val);
        $('#selectedCourseLabel').html(val === 'all' ? '<i class="fa-solid fa-book me-1 text-teal" style="color: #008080;"></i> All Courses' : '<i class="fa-solid fa-book-open me-1 text-teal" style="color: #008080;"></i> ' + label);
        $('#courseOptionsList .dropdown-course-item').removeClass('active-item');
        $(this).addClass('active-item');
        $('#courseDropdownMenu').addClass('d-none');
    });

    function renderLearnerOptions(learners, selectedVal) {
        let html = `
            <div class="dropdown-item-custom p-2 rounded cursor-pointer ${(!selectedVal || selectedVal === 'all') ? 'active-item' : ''}" data-value="all" data-label="All Learners (Everyone)" style="cursor: pointer;">
                <div class="fw-bold text-dark font-smallsize"><i class="fa-solid fa-users me-2 text-teal" style="color: #008080;"></i>All Learners (Everyone)</div>
                <small class="text-muted font-smallsize">Show records for all enrolled learners</small>
            </div>
        `;
        if (learners && learners.length > 0) {
            $.each(learners, function (idx, u) {
                let fullName = (u.first_name + ' ' + (u.last_name || '')).trim();
                let emailStr = u.email ? u.email : '';
                let empStr = u.emp_id ? u.emp_id : '';
                let isSel = (selectedVal == u.id) ? 'active-item' : '';
                let searchIndex = (fullName + ' ' + emailStr + ' ' + empStr).toLowerCase();
                let displayLabel = fullName + (emailStr ? ' (' + emailStr + ')' : '');

                if (selectedVal && selectedVal != 'all' && selectedVal == u.id) {
                    $('#selectedLearnerLabel').html('<i class="fa-solid fa-user me-1 text-teal" style="color: #008080;"></i> ' + displayLabel);
                }

                html += `
                    <div class="dropdown-item-custom p-2 rounded cursor-pointer border-bottom ${isSel}" data-value="${u.id}" data-search="${searchIndex}" data-label="${displayLabel}" style="cursor: pointer;">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="fw-semibold text-dark font-smallsize"><i class="fa-solid fa-user text-secondary me-1" style="font-size: 11px;"></i>${fullName}</span>
                            ${empStr ? `<span class="badge bg-light text-muted border font-smallsize">${empStr}</span>` : ''}
                        </div>
                        ${emailStr ? `<div class="text-muted font-smallsize ps-3">${emailStr}</div>` : ''}
                    </div>
                `;
            });
        }
        $('#learnerOptionsList').html(html);
    }

    function renderCourseOptions(courses, selectedVal) {
        let html = `
            <div class="dropdown-course-item p-2 rounded cursor-pointer ${(!selectedVal || selectedVal === 'all') ? 'active-item' : ''}" data-value="all" data-label="All Courses" style="cursor: pointer;">
                <div class="fw-bold text-dark font-smallsize"><i class="fa-solid fa-book me-2 text-teal" style="color: #008080;"></i>All Courses</div>
                <small class="text-muted font-smallsize">Show records for all courses</small>
            </div>
        `;
        if (courses && courses.length > 0) {
            $.each(courses, function (idx, c) {
                let title = c.course_name || c.course_code || 'Course';
                let code = c.course_code || '';
                let isSel = (selectedVal == c.id) ? 'active-item' : '';
                let searchIndex = (title + ' ' + code).toLowerCase();

                if (selectedVal && selectedVal != 'all' && selectedVal == c.id) {
                    $('#selectedCourseLabel').html('<i class="fa-solid fa-book-open me-1 text-teal" style="color: #008080;"></i> ' + title);
                }

                html += `
                    <div class="dropdown-course-item p-2 rounded cursor-pointer border-bottom ${isSel}" data-value="${c.id}" data-search="${searchIndex}" data-label="${title}" style="cursor: pointer;">
                        <div class="d-flex justify-content-between align-items-center">
                            <span class="fw-semibold text-dark font-smallsize"><i class="fa-solid fa-book-open text-secondary me-1" style="font-size: 11px;"></i>${title}</span>
                            ${code ? `<span class="badge bg-light text-muted border font-smallsize">${code}</span>` : ''}
                        </div>
                    </div>
                `;
            });
        }
        $('#courseOptionsList').html(html);
    }

    function getSelectedSources() {
        let sources = [];
        $('.source-checkbox:checked').each(function () {
            sources.push($(this).val());
        });
        if (sources.length === 0) {
            sources.push('learners');
            $('.source-checkbox[value="learners"]').prop('checked', true).closest('.source-card').addClass('border-teal bg-light shadow-sm');
        }
        return sources;
    }

    function updateSourcesBadge() {
        let count = $('.source-checkbox:checked').length;
        let text = count === 1 ? '1 Source Selected' : (count + ' Sources Selected');
        $('#selectedSourcesBadge').text(text);
    }

    function updateFieldOrderBadges() {
        // Sync checkboxes, cards and badges with selectedFieldsOrder
        $('.field-col-item').each(function () {
            let key = $(this).data('key');
            let idx = selectedFieldsOrder.indexOf(key);
            let $card = $(this).find('.form-check');
            let $cb = $(this).find('.field-checkbox');
            let $badge = $(this).find('.field-order-badge');

            if (idx !== -1) {
                $cb.prop('checked', true);
                $card.addClass('border-teal bg-light shadow-sm');
                $badge.text('#' + (idx + 1)).removeClass('d-none');
            } else {
                $cb.prop('checked', false);
                $card.removeClass('border-teal bg-light shadow-sm');
                $badge.text('').addClass('d-none');
            }
        });

        let count = selectedFieldsOrder.length;
        let text = count === 1 ? '1 column selected' : (count + ' columns selected');
        $('#selectedColumnsCount').text(text);

        // Keep form's ordered hidden fields container in sync for direct export
        let $container = $('#orderedFieldsContainer');
        if ($container.length === 0) {
            $('#reportBuilderForm').append('<div id="orderedFieldsContainer" style="display:none;"></div>');
            $container = $('#orderedFieldsContainer');
        }
        $container.empty();
        selectedFieldsOrder.forEach(function (fieldKey) {
            $container.append($('<input>').attr({
                type: 'hidden',
                name: 'fields[]',
                value: fieldKey
            }));
        });
    }

    function updateSelectedColumnsCount() {
        updateFieldOrderBadges();
    }

    // Toggle source checkbox & card style
    $(document).on('change', '.source-checkbox', function () {
        if ($(this).is(':checked')) {
            $(this).closest('.source-card').addClass('border-teal bg-light shadow-sm');
        } else {
            if ($('.source-checkbox:checked').length === 0) {
                $(this).prop('checked', true);
                return;
            }
            $(this).closest('.source-card').removeClass('border-teal bg-light shadow-sm');
        }
        updateSourcesBadge();
        loadMultiSourceSchema();
    });

    $('#btnSelectAllSources').on('click', function () {
        $('.source-checkbox').prop('checked', true);
        $('.source-card').addClass('border-teal bg-light shadow-sm');
        updateSourcesBadge();
        loadMultiSourceSchema();
    });

    $('#btnClearAllSources').on('click', function () {
        $('.source-checkbox').prop('checked', false);
        $('.source-card').removeClass('border-teal bg-light shadow-sm');
        let first = $('.source-checkbox').first();
        first.prop('checked', true);
        first.closest('.source-card').addClass('border-teal bg-light shadow-sm');
        updateSourcesBadge();
        loadMultiSourceSchema();
    });

    // Load initial schema
    updateSourcesBadge();
    loadMultiSourceSchema();

    // Date Presets Calculation Helper
    function applyDatePreset(preset) {
        if (!preset || preset === 'all' || preset === 'custom') {
            if (preset === 'all') {
                $('#dateFromFilter').val('');
                $('#dateToFilter').val('');
            }
            return;
        }
        let now = new Date();
        let fromDate = null;
        let toDate = null;

        function formatDate(d) {
            let year = d.getFullYear();
            let month = String(d.getMonth() + 1).padStart(2, '0');
            let day = String(d.getDate()).padStart(2, '0');
            return `${year}-${month}-${day}`;
        }

        if (preset === 'today') {
            fromDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            toDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        } else if (preset === 'yesterday') {
            let y = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
            fromDate = y;
            toDate = y;
        } else if (preset === 'last_7_days') {
            fromDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6);
            toDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        } else if (preset === 'last_30_days') {
            fromDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 29);
            toDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        } else if (preset === 'this_month') {
            fromDate = new Date(now.getFullYear(), now.getMonth(), 1);
            toDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        } else if (preset === 'last_month') {
            fromDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
            toDate = new Date(now.getFullYear(), now.getMonth(), 0);
        } else if (preset === 'last_3_months') {
            fromDate = new Date(now.getFullYear(), now.getMonth() - 3, 1);
            toDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
        } else if (preset === 'this_year') {
            fromDate = new Date(now.getFullYear(), 0, 1);
            toDate = new Date(now.getFullYear(), 11, 31);
        }

        if (fromDate) $('#dateFromFilter').val(formatDate(fromDate));
        if (toDate) $('#dateToFilter').val(formatDate(toDate));
    }

    $(document).on('change', '#datePresetFilter', function () {
        let preset = $(this).val();
        applyDatePreset(preset);
    });

    $(document).on('input change', '#dateFromFilter, #dateToFilter', function () {
        if ($('#datePresetFilter').val() !== 'custom' && ($('#dateFromFilter').val() || $('#dateToFilter').val())) {
            $('#datePresetFilter').val('custom');
        }
    });

    // Global Select / Deselect All visible fields
    $('#selectAllFields').on('click', function () { 
        $('.field-checkbox:visible').each(function () {
            let key = $(this).val();
            if (!selectedFieldsOrder.includes(key)) {
                selectedFieldsOrder.push(key);
            }
        });
        updateFieldOrderBadges();
    });

    $('#deselectAllFields').on('click', function () { 
        let visibleKeys = [];
        $('.field-checkbox:visible').each(function () {
            visibleKeys.push($(this).val());
        });
        selectedFieldsOrder = selectedFieldsOrder.filter(function (k) {
            return !visibleKeys.includes(k);
        });
        updateFieldOrderBadges();
    });

    // Source Group Select / Deselect
    $(document).on('click', '.btn-source-select-all', function () {
        let src = $(this).data('source');
        $(`.field-checkbox[data-source="${src}"]:visible`).each(function () {
            let key = $(this).val();
            if (!selectedFieldsOrder.includes(key)) {
                selectedFieldsOrder.push(key);
            }
        });
        updateFieldOrderBadges();
    });

    $(document).on('click', '.btn-source-deselect-all', function () {
        let src = $(this).data('source');
        let srcKeys = [];
        $(`.field-checkbox[data-source="${src}"]`).each(function () {
            srcKeys.push($(this).val());
        });
        selectedFieldsOrder = selectedFieldsOrder.filter(function (k) {
            return !srcKeys.includes(k);
        });
        updateFieldOrderBadges();
    });

    // Column checkbox toggle: when checked, push to END (becomes last column); when unchecked, remove
    $(document).on('change', '.field-checkbox', function () {
        let key = $(this).val();
        let isChecked = $(this).is(':checked');

        if (isChecked) {
            // Remove if already present (safety), and push to the end
            selectedFieldsOrder = selectedFieldsOrder.filter(function (f) { return f !== key; });
            selectedFieldsOrder.push(key);
        } else {
            // Remove from selected list
            selectedFieldsOrder = selectedFieldsOrder.filter(function (f) { return f !== key; });
        }
        updateFieldOrderBadges();
    });

    // Allow clicking anywhere on card to toggle checkbox
    $(document).on('click', '.field-col-item .form-check', function (e) {
        if ($(e.target).is('input') || $(e.target).is('label') || $(e.target).closest('label').length) {
            return;
        }
        let $cb = $(this).find('.field-checkbox');
        $cb.prop('checked', !$cb.prop('checked')).trigger('change');
    });

    // Live Column Search Filter
    $(document).on('input', '#columnSearchInput', function () {
        let q = $(this).val().toLowerCase().trim();
        if (!q) {
            $('.field-col-item').removeClass('d-none');
            $('.source-field-group').removeClass('d-none');
            $('.no-fields-matched-alert').addClass('d-none');
            return;
        }

        $('.source-field-group').each(function () {
            let group = $(this);
            let matchedInGroup = 0;
            group.find('.field-col-item').each(function () {
                let label = ($(this).data('label') || '').toString();
                let key = ($(this).data('key') || '').toString();
                if (label.indexOf(q) !== -1 || key.indexOf(q) !== -1) {
                    $(this).removeClass('d-none');
                    matchedInGroup++;
                } else {
                    $(this).addClass('d-none');
                }
            });

            if (matchedInGroup === 0) {
                group.find('.no-fields-matched-alert').removeClass('d-none');
                group.find('.fields-grid-container').addClass('d-none');
            } else {
                group.find('.no-fields-matched-alert').addClass('d-none');
                group.find('.fields-grid-container').removeClass('d-none');
                group.removeClass('d-none');
            }
        });
    });

    $('#addFilterBtn').on('click', function () { addFilterRow(); });
    $(document).on('click', '.btn-remove-filter', function () {
        $(this).closest('.filter-row').remove();
        if ($('.filter-row').length === 0) {
            $('#noFiltersText').show();
        }
    });

    // Dynamic Filter Input Change based on selected field
    $(document).on('change', '.filter-field-select', function () {
        let fieldKey = $(this).val();
        let row = $(this).closest('.filter-row');
        let rowId = row.data('row-id');
        let fieldMeta = currentSchema.fields[fieldKey] || {};
        row.find('.filter-input-wrapper').html(renderFilterInput(rowId, fieldMeta, '', ''));
    });

    function loadMultiSourceSchema() {
        let sources = getSelectedSources();
        $('#fieldsContainer').html('<div class="text-center py-4 text-muted"><i class="fa-solid fa-spinner fa-spin me-2 text-teal" style="color: #008080;"></i> Loading fields for selected data sources...</div>');

        // Toggle dedicated standalone dropdown filters based on selected sources
        if (sources.includes('assessments')) {
            $('#assessmentDedicatedFilterWrapper').removeClass('d-none');
            if (!isInitialLoad) $('#assessmentQuickFilter').val('Total');
        } else {
            $('#assessmentDedicatedFilterWrapper').addClass('d-none');
        }

        if (sources.includes('certificates')) {
            $('#certificatesDedicatedFilterWrapper').removeClass('d-none');
            if (!isInitialLoad) $('#certificateStatusQuickFilter').val('All');
        } else {
            $('#certificatesDedicatedFilterWrapper').addClass('d-none');
        }

        if (sources.includes('feedback')) {
            $('#feedbackDedicatedFilterWrapper').removeClass('d-none');
            if (!isInitialLoad) $('#feedbackTypeQuickFilter').val('Total');
        } else {
            $('#feedbackDedicatedFilterWrapper').addClass('d-none');
        }

        if (sources.includes('videos')) {
            $('#videosDedicatedFilterWrapper').removeClass('d-none');
            if (!isInitialLoad) {
                $('#videoTypeQuickFilter').val('All');
                $('#videoWatchQuickFilter').val('Total');
            }
        } else {
            $('#videosDedicatedFilterWrapper').addClass('d-none');
        }

        if (sources.includes('exams')) {
            $('#examsDedicatedFilterWrapper').removeClass('d-none');
            if (!isInitialLoad) $('#examResultQuickFilter').val('Total');
        } else {
            $('#examsDedicatedFilterWrapper').addClass('d-none');
        }

        updateStatusFilterOptions(sources);

        $.ajax({
            url: "{{ route('admin.reports.schema') }}",
            type: "GET",
            data: { data_sources: sources },
            success: function (res) {
                if (res.success) {
                    currentSchema = res.schema;
                    renderCategorizedFields(currentSchema.fields_by_source, currentSchema.fields);
                    renderSortOptions(currentSchema.fields, currentSchema.fields_by_source);

                    // Render searchable course and learner dropdowns
                    renderCourseOptions(res.schema.courses, $('#universalCourseFilter').val());
                    renderLearnerOptions(res.schema.learners, $('#universalLearnerFilter').val());

                    $('#filtersContainer').empty();
                    filterIndex = 0;

                    if (isInitialLoad && Array.isArray(savedDynamicFilters) && savedDynamicFilters.length > 0) {
                        $('#noFiltersText').hide();
                        $.each(savedDynamicFilters, function (idx, flt) {
                            addFilterRow(flt);
                        });
                    } else {
                        $('#noFiltersText').show();
                    }

                    isInitialLoad = false;
                }
            }
        });
    }

    function updateStatusFilterOptions(sources, selectedVal) {
        let currentVal = selectedVal || $('#universalStatusFilter').val() || 'all';
        let optionsHtml = '';
        if (Array.isArray(sources) && sources.includes('exams') && sources.length === 1) {
            $('#universalStatusFilterLabel').html('<i class="fa-solid fa-list-check text-teal me-1" style="color: #008080;"></i> Exam Result / Status:');
            optionsHtml = `
                <option value="all" ${currentVal === 'all' ? 'selected' : ''}>All Results & Statuses</option>
                <option value="passed" ${currentVal === 'passed' ? 'selected' : ''}>Passed</option>
                <option value="failed" ${currentVal === 'failed' ? 'selected' : ''}>Failed</option>
                <option value="pending" ${currentVal === 'pending' ? 'selected' : ''}>Pending Evaluation</option>
                <option value="not_started" ${currentVal === 'not_started' ? 'selected' : ''}>Not Started / Not Attempted</option>
            `;
        } else {
            $('#universalStatusFilterLabel').html('<i class="fa-solid fa-list-check text-teal me-1" style="color: #008080;"></i> Course Status:');
            optionsHtml = `
                <option value="all" ${currentVal === 'all' ? 'selected' : ''}>All Statuses</option>
                <option value="in_progress" ${currentVal === 'in_progress' || currentVal === 'incomplete' ? 'selected' : ''}>In Progress</option>
                <option value="completed" ${currentVal === 'completed' ? 'selected' : ''}>Completed</option>
                <option value="not_started" ${currentVal === 'not_started' ? 'selected' : ''}>Not Started</option>
                <option value="expired" ${currentVal === 'expired' ? 'selected' : ''}>Expired</option>
            `;
        }
        $('#universalStatusFilter').html(optionsHtml);
    }

    function renderCategorizedFields(fieldsBySource, flatFields) {
        let validKeys = flatFields ? Object.keys(flatFields) : [];
        if (validKeys.length === 0 && fieldsBySource) {
            $.each(fieldsBySource, function (sKey, grp) {
                if (grp.fields) {
                    validKeys = validKeys.concat(Object.keys(grp.fields));
                }
            });
        }

        // If initial load and selectedFieldsOrder is empty, populate from savedFields
        if (selectedFieldsOrder.length === 0 && isInitialLoad && Array.isArray(savedFields) && savedFields.length > 0) {
            savedFields.forEach(function (k) {
                if (!selectedFieldsOrder.includes(k)) {
                    selectedFieldsOrder.push(k);
                }
            });
        }

        // Filter existing selection to keep only active fields
        selectedFieldsOrder = selectedFieldsOrder.filter(function (key) {
            return validKeys.includes(key);
        });

        // If still empty (e.g. no saved fields or completely new source), populate with defaults
        if (selectedFieldsOrder.length === 0) {
            if (fieldsBySource && Object.keys(fieldsBySource).length > 0) {
                $.each(fieldsBySource, function (srcKey, group) {
                    let fields = group.fields || {};
                    $.each(fields, function (key, item) {
                        if (item.default && !selectedFieldsOrder.includes(key)) {
                            selectedFieldsOrder.push(key);
                        }
                    });
                });
            } else if (flatFields) {
                $.each(flatFields, function (key, item) {
                    if (item.default && !selectedFieldsOrder.includes(key)) {
                        selectedFieldsOrder.push(key);
                    }
                });
            }
        }

        let html = '';
        if (fieldsBySource && Object.keys(fieldsBySource).length > 0) {
            $.each(fieldsBySource, function (srcKey, group) {
                let srcLabel = group.label || srcKey;
                let srcIcon = group.icon || 'fa-solid fa-table';
                let fields = group.fields || {};
                let fieldCount = Object.keys(fields).length;
                if (fieldCount === 0) return;

                html += `
                    <div class="card card-border shadow-none border mb-3 source-field-group" data-source="${srcKey}">
                        <div class="card-header bg-white py-2 px-3 border-bottom d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <div class="d-flex align-items-center">
                                <i class="${srcIcon} me-2 text-teal" style="color: #008080; font-size: 15px;"></i>
                                <span class="fw-bold text-dark font-smallsize">${srcLabel}</span>
                                <span class="badge bg-light text-dark border ms-2 font-smallsize">${fieldCount} Available Fields</span>
                            </div>
                            <div class="d-flex gap-1">
                                <button type="button" class="btn btn-xs btn-outline-teal btn-source-select-all" data-source="${srcKey}" style="font-size: 11px; padding: 2px 7px; color: #008080; border-color: #008080;">
                                    <i class="fa-solid fa-check me-1"></i>Select All
                                </button>
                                <button type="button" class="btn btn-xs btn-outline-secondary btn-source-deselect-all" data-source="${srcKey}" style="font-size: 11px; padding: 2px 7px;">
                                    <i class="fa-solid fa-xmark me-1"></i>Deselect All
                                </button>
                            </div>
                        </div>
                        <div class="card-body p-3">
                            <div class="row g-2 fields-grid-container">
                `;

                $.each(fields, function (key, item) {
                    let isChecked = selectedFieldsOrder.includes(key);
                    let orderIdx = selectedFieldsOrder.indexOf(key);
                    let orderNum = orderIdx !== -1 ? (orderIdx + 1) : null;
                    let activeCardClass = isChecked ? 'border-teal bg-light shadow-sm' : '';
                    let checkedAttr = isChecked ? 'checked' : '';
                    let searchIndex = (item.label + ' ' + key).toLowerCase();
                    let safeKey = key.replace(/[^a-zA-Z0-9_]/g, '_');
                    html += `
                        <div class="col-md-4 col-sm-6 field-col-item" data-key="${key}" data-label="${searchIndex}">
                            <div class="form-check p-2 border rounded bg-white shadow-sm h-100 ${activeCardClass}" style="transition: all 0.2s ease; cursor: pointer;">
                                <div class="d-flex align-items-center justify-content-between">
                                    <div class="d-flex align-items-center me-2 overflow-hidden flex-grow-1">
                                        <input class="form-check-input field-checkbox me-2" type="checkbox" value="${key}" id="field_${safeKey}_${srcKey}" data-source="${srcKey}" ${checkedAttr} style="cursor: pointer; flex-shrink: 0;">
                                        <label class="form-check-label font-smallsize cursor-pointer text-dark fw-medium text-truncate mb-0" for="field_${safeKey}_${srcKey}" title="${item.label}">
                                            ${item.label}
                                        </label>
                                    </div>
                                    <span class="badge rounded-pill field-order-badge px-2 py-1 ${orderNum ? '' : 'd-none'}" style="background-color: #008080; color: #fff; font-size: 10px; font-weight: 700; flex-shrink: 0; min-width: 24px; text-align: center;">
                                        ${orderNum ? '#' + orderNum : ''}
                                    </span>
                                </div>
                            </div>
                        </div>
                    `;
                });

                html += `
                            </div>
                            <div class="no-fields-matched-alert d-none text-muted font-smallsize text-center py-2">
                                <i class="fa-solid fa-filter me-1 text-warning"></i> No fields in this section match the search.
                            </div>
                        </div>
                    </div>
                `;
            });
        } else if (flatFields) {
            html += '<div class="row g-2">';
            $.each(flatFields, function (key, item) {
                let isChecked = selectedFieldsOrder.includes(key);
                let orderIdx = selectedFieldsOrder.indexOf(key);
                let orderNum = orderIdx !== -1 ? (orderIdx + 1) : null;
                let activeCardClass = isChecked ? 'border-teal bg-light shadow-sm' : '';
                let checkedAttr = isChecked ? 'checked' : '';
                let safeKey = key.replace(/[^a-zA-Z0-9_]/g, '_');
                html += `
                    <div class="col-md-4 col-sm-6 field-col-item" data-key="${key}" data-label="${(item.label + ' ' + key).toLowerCase()}">
                        <div class="form-check p-2 border rounded bg-white shadow-sm h-100 ${activeCardClass}" style="transition: all 0.2s ease; cursor: pointer;">
                            <div class="d-flex align-items-center justify-content-between">
                                <div class="d-flex align-items-center me-2 overflow-hidden flex-grow-1">
                                    <input class="form-check-input field-checkbox me-2" type="checkbox" value="${key}" id="field_${safeKey}" ${checkedAttr} style="cursor: pointer; flex-shrink: 0;">
                                    <label class="form-check-label font-smallsize cursor-pointer text-dark fw-medium text-truncate mb-0" for="field_${safeKey}" title="${item.label}">
                                        ${item.label}
                                    </label>
                                </div>
                                <span class="badge rounded-pill field-order-badge px-2 py-1 ${orderNum ? '' : 'd-none'}" style="background-color: #008080; color: #fff; font-size: 10px; font-weight: 700; flex-shrink: 0; min-width: 24px; text-align: center;">
                                    ${orderNum ? '#' + orderNum : ''}
                                </span>
                            </div>
                        </div>
                    </div>
                `;
            });
            html += '</div>';
        }
        $('#fieldsContainer').html(html);
        updateFieldOrderBadges();
    }

    function renderSummaryOptions(summaryOptions) {
        let html = '';
        if (summaryOptions) {
            $.each(summaryOptions, function (key, label) {
                html += `<option value="${key}">${label}</option>`;
            });
        }
        if (!html) {
            html = '<option value="COUNT">Total Count</option>';
        }
        $('#calcTypeSelect').html(html);
    }

    function renderSortOptions(fields, fieldsBySource) {
        let sortHtml = '';
        if (fieldsBySource && Object.keys(fieldsBySource).length > 1) {
            $.each(fieldsBySource, function (srcKey, group) {
                sortHtml += `<optgroup label="${group.label}">`;
                $.each(group.fields, function (key, item) {
                    let isSel = (savedSortField && savedSortField === key) ? 'selected' : '';
                    sortHtml += `<option value="${key}" ${isSel}>${item.label}</option>`;
                });
                sortHtml += `</optgroup>`;
            });
        } else {
            $.each(fields, function (key, item) {
                let isSel = (savedSortField && savedSortField === key) ? 'selected' : '';
                sortHtml += `<option value="${key}" ${isSel}>${item.label}</option>`;
            });
        }
        $('#sortFieldSelect').html(sortHtml);
    }

    // Generate input based on field type
    function renderFilterInput(rowId, fieldMeta, val = '', valTo = '') {
        if (fieldMeta.type === 'select' && fieldMeta.options) {
            let optHtml = '';
            let hasAll = fieldMeta.options.hasOwnProperty('Total') || fieldMeta.options.hasOwnProperty('All') || fieldMeta.options.hasOwnProperty('');
            if (!hasAll) {
                optHtml += '<option value="">-- All / Any --</option>';
            }
            $.each(fieldMeta.options, function (optVal, optLabel) {
                let isFirst = (optVal === 'Total' || optVal === 'All' || optVal === '');
                let sel = (val == optVal || (!val && isFirst)) ? 'selected' : '';
                optHtml += `<option value="${optVal}" ${sel}>${optLabel}</option>`;
            });
            return `<select name="filters[${rowId}][value]" class="form-select form-select-sm filter-val">${optHtml}</select>`;
        } else if (fieldMeta.type === 'date') {
            return `
                <div class="d-flex gap-2 align-items-center">
                    <input type="date" name="filters[${rowId}][value]" class="form-control form-control-sm filter-val" value="${val}" title="From Date">
                    <span class="text-muted font-smallsize">to</span>
                    <input type="date" name="filters[${rowId}][value_to]" class="form-control form-control-sm filter-val-to" value="${valTo}" title="To Date">
                </div>
            `;
        } else if (fieldMeta.type === 'number') {
            return `<input type="number" name="filters[${rowId}][value]" class="form-control form-control-sm filter-val" placeholder="Enter number (e.g. 70)..." value="${val}">`;
        } else {
            return `<input type="text" name="filters[${rowId}][value]" class="form-control form-control-sm filter-val" placeholder="Search keyword (e.g. CECO, Rahul)..." value="${val}">`;
        }
    }

    // Add a Dynamic Filter Row
    function addFilterRow(existingFilter = null) {
        if (!currentSchema) return;
        $('#noFiltersText').hide();

        let rowId = filterIndex++;
        let firstFieldKey = Object.keys(currentSchema.fields)[0];
        let selectedField = existingFilter ? existingFilter.field : firstFieldKey;
        let fieldMeta = currentSchema.fields[selectedField] || {};

        let fieldOptions = '';
        if (currentSchema.fields_by_source && Object.keys(currentSchema.fields_by_source).length > 1) {
            $.each(currentSchema.fields_by_source, function (srcKey, group) {
                fieldOptions += `<optgroup label="${group.label}">`;
                $.each(group.fields, function (key, item) {
                    let sel = (selectedField === key) ? 'selected' : '';
                    fieldOptions += `<option value="${key}" ${sel}>${item.label}</option>`;
                });
                fieldOptions += `</optgroup>`;
            });
        } else {
            $.each(currentSchema.fields, function (key, item) {
                let sel = (selectedField === key) ? 'selected' : '';
                fieldOptions += `<option value="${key}" ${sel}>${item.label}</option>`;
            });
        }

        let inputHtml = renderFilterInput(rowId, fieldMeta, existingFilter ? (existingFilter.value || '') : '', existingFilter ? (existingFilter.value_to || '') : '');

        let rowHtml = `
            <div class="row g-2 align-items-center mb-2 filter-row p-2 border rounded bg-light" id="filter_row_${rowId}" data-row-id="${rowId}">
                <div class="col-md-5">
                    <label class="form-label font-smallsize text-muted mb-1">Filter Field</label>
                    <select name="filters[${rowId}][field]" class="form-select form-select-sm filter-field-select">
                        ${fieldOptions}
                    </select>
                </div>
                <div class="col-md-6 filter-input-wrapper">
                    <label class="form-label font-smallsize text-muted mb-1">Search Keyword / Value</label>
                    ${inputHtml}
                </div>
                <div class="col-md-1 text-center pt-3">
                    <button type="button" class="btn btn-sm btn-outline-danger btn-remove-filter" title="Remove Filter"><i class="fa-solid fa-trash"></i></button>
                </div>
            </div>
        `;

        $('#filtersContainer').append(rowHtml);
    }

    // Live Preview
    $('#btnPreview').on('click', function () {
        let $btn = $(this);
        $btn.prop('disabled', true).html('<i class="fa-solid fa-spinner fa-spin me-1"></i> Querying...');

        $('#previewCard').removeClass('d-none');
        $('#previewThead').html('<tr><th class="text-center py-3"><i class="fa-solid fa-spinner fa-spin me-2"></i> Querying LMS database...</th></tr>');
        $('#previewTbody').empty();
        $('#chartPreviewWrapper').addClass('d-none');

        $('html, body').animate({ scrollTop: $("#previewCard").offset().top - 80 }, 200);

        let sources = getSelectedSources();
        let dataSource = sources[0] || 'learners';
        let fields = selectedFieldsOrder.slice();

        let filters = [];
        $('.filter-row').each(function () {
            let field = $(this).find('.filter-field-select').val();
            let val = $(this).find('.filter-val').val();
            let valTo = $(this).find('.filter-val-to').val();
            if (field && (val || valTo)) {
                filters.push({ field: field, value: val, value_to: valTo });
            }
        });

        let payload = {
            _token: "{{ csrf_token() }}",
            data_sources: sources,
            data_source: dataSource,
            fields: fields,
            filters: filters,
            learner_filter: $('#universalLearnerFilter').val(),
            course_filter: $('#universalCourseFilter').val(),
            date_preset: $('#datePresetFilter').val(),
            date_from: $('#dateFromFilter').val(),
            date_to: $('#dateToFilter').val(),
            status_filter: $('#universalStatusFilter').val(),
            assessment_name_filter: $('#assessmentNameFilter').val(),
            assessment_assignment_filter: $('#assessmentQuickFilter').val(),
            certificate_status_filter: $('#certificateStatusQuickFilter').val(),
            feedback_type_filter: $('#feedbackTypeQuickFilter').val(),
            video_type_filter: $('#videoTypeQuickFilter').val(),
            video_watch_filter: $('#videoWatchQuickFilter').val(),
            exam_result_filter: $('#examResultQuickFilter').val(),
            group_by: 'none_individual',
            calculation: {
                type: $('#calcTypeSelect').val()
            },
            sort_field: $('#sortFieldSelect').val(),
            sort_direction: $('select[name="sort_direction"]').val(),
            output_type: $('#outputTypeInput').val() || 'table'
        };

        $.ajax({
            url: "{{ route('admin.reports.preview') }}",
            type: "POST",
            data: payload,
            dataType: "json",
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}",
                'Accept': 'application/json'
            },
            timeout: 120000,
            success: function (res) {
                $btn.prop('disabled', false).html('<i class="fa-solid fa-eye me-1"></i> Live Preview');
                if (res.success && res.data) {
                    renderPreviewResults(res.data);
                } else {
                    $('#previewThead').html('<tr><th class="text-danger py-3 text-center">Failed to generate preview.</th></tr>');
                }
            },
            error: function (xhr, status, error) {
                $btn.prop('disabled', false).html('<i class="fa-solid fa-eye me-1"></i> Live Preview');
                let msg = status === 'timeout'
                    ? 'The report took longer than two minutes. Select a smaller date range or add filters and try again.'
                    : ((xhr.responseJSON && xhr.responseJSON.message) ? xhr.responseJSON.message : ('Error: ' + (error || 'Network error')));
                $('#previewThead').empty().append(
                    $('<tr>').append($('<th>').addClass('text-danger py-3 text-center').text(msg))
                );
            }
        });
    });

    function renderPreviewResults(data) {
        $('#previewCount').text(data.total_count);

        let theadHtml = '<tr>';
        $.each(data.headers, function (i, h) {
            let colStyle = 'style="white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            if (h === 'Course Name') {
                colStyle = 'style="min-width: 240px; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h.indexOf('Assessment Name') !== -1 || h.indexOf('Assignment Name') !== -1 || h.indexOf('Content Title') !== -1 || h === 'Exam Name') {
                colStyle = 'style="min-width: 250px; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h.indexOf('Users') !== -1) {
                colStyle = 'style="min-width: 220px; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h.indexOf('Attempts') !== -1) {
                colStyle = 'style="min-width: 110px; text-align: center; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h === 'Learner Email') {
                colStyle = 'style="min-width: 220px; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h.indexOf('Watch Status') !== -1) {
                colStyle = 'style="min-width: 130px; text-align: center; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h.indexOf('Course Status') !== -1) {
                colStyle = 'style="min-width: 130px; text-align: center; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h.indexOf('Result') !== -1) {
                colStyle = 'style="min-width: 130px; text-align: center; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h.indexOf('Marks') !== -1) {
                colStyle = 'style="min-width: 100px; text-align: center; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h.indexOf('Score') !== -1) {
                colStyle = 'style="min-width: 90px; text-align: center; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h.indexOf('Time') !== -1) {
                colStyle = 'style="min-width: 110px; text-align: center; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h === 'Status') {
                colStyle = 'style="min-width: 120px; text-align: center; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h.indexOf('Assigned Date') !== -1) {
                colStyle = 'style="min-width: 130px; text-align: center; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h.indexOf('Attend Date') !== -1 || h.indexOf('Start Date') !== -1) {
                colStyle = 'style="min-width: 150px; text-align: center; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h.indexOf('Completed') !== -1) {
                colStyle = 'style="min-width: 150px; text-align: center; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            } else if (h.indexOf('Assessment Status') !== -1 || h.indexOf('Assignment Status') !== -1) {
                colStyle = 'style="min-width: 140px; text-align: center; white-space: nowrap; vertical-align: middle; padding: 10px 12px; font-weight: 600; font-size: 13px;"';
            }
            theadHtml += `<th ${colStyle}>${h}</th>`;
        });
        theadHtml += '</tr>';
        $('#previewThead').html(theadHtml);

        let tbodyHtml = '';
        if (data.rows.length === 0) {
            tbodyHtml = `<tr><td colspan="${data.headers.length}" class="text-center py-4 text-muted align-top">No records match the selected search criteria.</td></tr>`;
        } else {
            $.each(data.rows, function (i, r) {
                tbodyHtml += '<tr>';
                let rowspans = r._rowspans || null;

                if (rowspans && typeof rowspans === 'object') {
                    for (let j = 0; j < data.headers.length; j++) {
                        let span = typeof rowspans[j] !== 'undefined' ? rowspans[j] : 1;
                        if (span > 0) {
                            let hName = data.headers[j] || '';
                            let isCenter = hName.indexOf('Attempts') !== -1 || hName.indexOf('Result') !== -1 || hName.indexOf('Marks') !== -1 || hName.indexOf('Score') !== -1 || hName.indexOf('Time') !== -1 || hName.indexOf('Status') !== -1 || hName.indexOf('Date') !== -1 || hName.indexOf('Completed') !== -1 || hName.indexOf('Count') !== -1 || hName.indexOf('Rate') !== -1;
                            let cellAlign = isCenter ? 'text-center' : 'text-start';
                            let spanAttr = span > 1 ? `rowspan="${span}"` : '';
                            let bgStyle = span > 1 ? 'background-color: #ffffff;' : '';
                            tbodyHtml += `<td ${spanAttr} class="align-top ${cellAlign}" style="padding: 8px 10px; vertical-align: top !important; border: 1px solid #e9ecef; ${bgStyle}">${r[j] !== null && r[j] !== undefined ? r[j] : '-'}</td>`;
                        }
                    }
                } else if (typeof r._course_rowspan !== 'undefined') {
                    let courseRowspan = r._course_rowspan || 0;
                    let itemRowspan = r._item_rowspan || 0;
                    if (courseRowspan > 0) {
                        tbodyHtml += `<td rowspan="${courseRowspan}" class="align-top text-start" style="vertical-align: top !important; background-color: #ffffff; padding: 10px 12px; border: 1px solid #e9ecef;">${r[0] !== null ? r[0] : '-'}</td>`;
                    }
                    let startIdx = 1;
                    if (typeof r._item_rowspan !== 'undefined') {
                        if (itemRowspan > 0) {
                            tbodyHtml += `<td rowspan="${itemRowspan}" class="align-top text-start" style="vertical-align: top !important; background-color: #ffffff; padding: 10px 12px; border: 1px solid #e9ecef;">${r[1] !== null ? r[1] : '-'}</td>`;
                        }
                        startIdx = 2;
                    }
                    for (let j = startIdx; j < data.headers.length; j++) {
                        let hName = data.headers[j] || '';
                        let isCenter = hName.indexOf('Attempts') !== -1 || hName.indexOf('Result') !== -1 || hName.indexOf('Marks') !== -1 || hName.indexOf('Score') !== -1 || hName.indexOf('Time') !== -1 || hName.indexOf('Status') !== -1 || hName.indexOf('Date') !== -1 || hName.indexOf('Completed') !== -1;
                        let cellAlign = isCenter ? 'text-center' : 'text-start';
                        tbodyHtml += `<td class="align-middle ${cellAlign}" style="padding: 8px 10px; vertical-align: middle !important; border: 1px solid #e9ecef;">${r[j] !== null && r[j] !== undefined ? r[j] : '-'}</td>`;
                    }
                } else {
                    $.each(r, function (j, cell) {
                        if (typeof j === 'string' && j.startsWith('_')) return;
                        let hName = data.headers[j] || '';
                        let isCenter = hName.indexOf('Attempts') !== -1 || hName.indexOf('Result') !== -1 || hName.indexOf('Marks') !== -1 || hName.indexOf('Score') !== -1 || hName.indexOf('Time') !== -1 || hName.indexOf('Status') !== -1 || hName.indexOf('Date') !== -1 || hName.indexOf('Completed') !== -1;
                        let cellAlign = isCenter ? 'text-center' : 'text-start';
                        tbodyHtml += `<td class="align-top ${cellAlign}" style="padding: 8px 10px; vertical-align: top !important; border: 1px solid #e9ecef;">${cell !== null ? cell : '-'}</td>`;
                    });
                }
                tbodyHtml += '</tr>';
            });
        }
        $('#previewTbody').html(tbodyHtml);

        if (data.chart_data && (data.output_type === 'bar' || data.output_type === 'line' || data.output_type === 'pie' || data.output_type === 'doughnut')) {
            $('#chartPreviewWrapper').removeClass('d-none');

            if (chartInstance) {
                chartInstance.destroy();
                chartInstance = null;
            }

            $('#chartPreviewWrapper').html('<canvas id="previewChart" style="max-height: 380px; width: 100%;"></canvas>');

            let ctx = document.getElementById('previewChart').getContext('2d');
            chartInstance = new Chart(ctx, {
                type: data.chart_data.type,
                data: {
                    labels: data.chart_data.labels,
                    datasets: data.chart_data.datasets
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: (data.chart_data.type === 'pie' || data.chart_data.type === 'doughnut'),
                            position: 'bottom'
                        }
                    }
                }
            });
        } else {
            $('#chartPreviewWrapper').addClass('d-none');
            if (chartInstance) {
                chartInstance.destroy();
                chartInstance = null;
            }
        }
    }

    $('#btnOpenSaveModal').on('click', function () { $('#saveReportModal').modal('show'); });

    $('#btnConfirmSave').on('click', function () {
        let name = $('#saveReportName').val().trim();
        if (!name) {
            alert('Please enter a report name.');
            return;
        }

        let desc = $('#saveReportDesc').val().trim();
        let sources = getSelectedSources();
        let dataSource = sources.join(',');

        let config = {
            data_source: dataSource,
            data_sources: sources,
            fields: [],
            filters: [],
            learner_filter: $('#universalLearnerFilter').val(),
            course_filter: $('#universalCourseFilter').val(),
            date_preset: $('#datePresetFilter').val(),
            date_from: $('#dateFromFilter').val(),
            date_to: $('#dateToFilter').val(),
            status_filter: $('#universalStatusFilter').val(),
            assessment_name_filter: $('#assessmentNameFilter').val(),
            assessment_assignment_filter: $('#assessmentQuickFilter').val(),
            certificate_status_filter: $('#certificateStatusQuickFilter').val(),
            feedback_type_filter: $('#feedbackTypeQuickFilter').val(),
            video_type_filter: $('#videoTypeQuickFilter').val(),
            video_watch_filter: $('#videoWatchQuickFilter').val(),
            exam_result_filter: $('#examResultQuickFilter').val(),
            group_by: 'none_individual',
            calculation: {
                type: $('#calcTypeSelect').val()
            },
            sort_field: $('#sortFieldSelect').val(),
            sort_direction: $('select[name="sort_direction"]').val(),
            output_type: $('#outputTypeInput').val() || 'table'
        };

        config.fields = selectedFieldsOrder.slice();

        $('.filter-row').each(function () {
            let field = $(this).find('.filter-field-select').val();
            let val = $(this).find('.filter-val').val();
            let valTo = $(this).find('.filter-val-to').val();
            if (field && (val || valTo)) {
                config.filters.push({ field: field, value: val, value_to: valTo });
            }
        });

        $.ajax({
            url: "{{ route('admin.reports.update', $report->id) }}",
            type: "POST",
            data: {
                _token: "{{ csrf_token() }}",
                _method: "PUT",
                name: name,
                description: desc,
                data_source: dataSource,
                data_sources: sources,
                configuration: config
            },
            success: function (res) {
                if (res.success) {
                    $('#saveReportModal').modal('hide');
                    window.location.href = res.redirect_url;
                }
            },
            error: function (xhr) {
                alert('Error saving report: ' + (xhr.responseJSON ? xhr.responseJSON.message : 'Please check inputs.'));
            }
        });
    });

    $(document).on('click', '.btn-export-preview', function (e) {
        e.preventDefault();
        updateFieldOrderBadges();
        let format = $(this).data('format');
        let form = $('#reportBuilderForm');
        let prevAction = form.attr('action');
        let prevTarget = form.attr('target');
        let prevMethod = form.attr('method');

        let exportUrl = "{{ url('admin/reports/export-direct') }}/" + format;

        form.attr('action', exportUrl);
        form.attr('method', 'POST');
        form.attr('target', '_blank');
        form.submit();

        setTimeout(function () {
            form.attr('action', prevAction || '');
            form.attr('target', prevTarget || '_self');
            form.attr('method', prevMethod || 'POST');
        }, 500);
    });
});
</script>

@include('layouts.admin.footer')

